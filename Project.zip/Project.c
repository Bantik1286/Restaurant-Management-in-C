//  Roll Number               Name              section
//  19K-0258                  Zubair Ahmed       D
//  19K-0180                  Banti Kumar        D
//  19K-1302                  Alkesh Raj         D
                   
#include<stdio.h>
#include<stdlib.h>
struct pro
{
	char name[100],username[100],password[100],nic[100],email[100];
	float salary,wallet;
	int date,month,year;
};

struct menu
{
	float price;
	char name[100];
};
void dltcustomer(void);
void customerread(struct pro *p,int i);
void customerwallet(void);
void customerreg(void);
void customer(void);
void findme(struct pro id);
void admincount(int *i);
void editmenu(void);
void display(void);
void owner(int *b);
void reg_admin(void);
void admin(int*);
void customercount(int *i);
void adminread(struct pro*p, int i);
void order(float *sum,int per);
int main()
{
	int a;
	while(1)
	{
		printf("1 owner \n\n2 admin\n\n3 customer\n\n4 Exit ");
		scanf("%d",&a);
		if(a==1)
		{
			owner(&a);
		}
		if(a==2)
		{
			admin(&a);
		}
		if(a==3)
		{
		customer();	
		}
		if(a==4)
		{
			break;
		}
	}
}
void owner(int *b)                                       
{
	system("cls");
	int a,i,temp,j,d=0;
	FILE *fp;
	struct pro o,data,admins,*p;
	fflush(stdin);
	printf("\n\n\n\n\t\t\t\tEnter username ");
	gets(o.username);
	fp=fopen("owner.dat","rb");
	if(fp==NULL)
	{
		printf("File not exists ");
		exit(1);
	}
	fread(&data,sizeof(struct pro),1,fp);
	fclose(fp);
	if(strcmp(o.username,data.username)==0)
	{
		for(i=0;data.password[i]!='\0';i++)
		{
			data.password[i]=data.password[i]-2;                                   
		}
		printf("\n\n\t\t\t\tEnter password ");
		gets(o.password);
		if(strcmp(o.password,data.password)==0)
		{
			while(1)
			{
				system("cls");
				printf("\n\n\t\t\t\t\t Welcome Mr %s \n\n",data.name);
				printf("1 register any admin \n\n2 Edit Menu card \n\n3 Detail of registered admins\n\n4 Change account\n\n5 remove any admin\n\n6 wallet and detail of regisstered customers\n\n7 back \n\n8 Exit\n\n select ");
				scanf("%d",&a);
		        switch(a)
				{  case 1:
					  reg_admin();
						break;
					case 2:
					editmenu();
						break;
					case 3:
						system("cls");
					admincount(&i);
					fp=fopen("admin.txt","rb");
					printf("NAME\t\tNIC no.\t\t\t\t Date/Month/Year of joining\t\t salary \n\n");
					while(fread(&admins,sizeof(struct pro),1,fp))
					printf("%s\t\t%s\t\t\t\t%d/%d/%d\t\t%.2f\n\n",admins.name,admins.nic,admins.date,admins.month,admins.year,admins.salary);
					getch();
						break;
					case 4:
					  printf("Enter new name ");
					  fflush(stdin);
					  gets(o.name);
					  printf("Username ");
					  gets(o.username);
					  printf("New password ");
					  gets(o.password);
					  for(i=0;o.password[i]!='\0';i++)
					  {
					  	o.password[i]=o.password[i]+2;
					  }
					  printf("Enter NIC number ");
					  gets(o.nic);
					    printf("your previous account will be remove, for save changes press 1 ");
					    scanf("%d",&i);
					    if(i==1)
					    {
					    	fp=fopen("owner.dat","wb");
					        fwrite(&o,sizeof(struct pro),1,fp);
					        fclose(fp);
						}
						break;
						case 5: 
						      i=0;                                                        
								admincount(&i);
							    p= (struct pro*) calloc(i,sizeof(struct pro));
								adminread(p,i);
								printf("Name\t\t\tNIC No. \n\n");
								for(j=0;j<i;j++)
								{
									printf("%s\t\t\t%s\n",p[j].name,p[j].nic);
								}	
								fflush(stdin);
								printf("\nEnter the admin NIC no  that you want to delete \n  ");
								gets(admins.nic);
								for(j=0;j<i;j++)
							    	{
										if(strcmp(p[j].nic,admins.nic)==0)
										{
									     temp=j;
					                     d=1;				
										break;}
									}
						
					           if(d==1)
					           {
				                    for(j=temp;j<i;j++)
									{
										p[j]=p[j+1];
									}
									   fp=fopen("admin.txt","wb");
					                  fwrite(p,sizeof(struct pro),i-1,fp);
					                  fclose(fp);
							   }
							   else
							   {
							   	printf("Not registered yet ");
							   }
							   free(p);
							   break;
							   case 6:
							  customerwallet();
							  break;}
							  if(a==7)
							  {
							  	break;
							  }
							  if(a==8)
							  {
							  	*b=4;break;
							  }
							  
							
						}}
						else
						{
							printf("1 for forget password ");
							scanf("%d",&a);
							if(a==1)
							{
								findme(data);
							}
						}
						
						}}
								
void reg_admin(void)                                    
{
	FILE *fp;
	system("cls");
	int i=0,count,j;
    admincount(&i);
	struct pro data[i];
	adminread(data,i);
	struct pro s;
	fflush(stdin);
	printf("Enter name ");
     gets(s.name);
     printf("Enter the NIC ");
     gets(s.nic);
     for(j=0;j<i;j++)
     {
      if(strcmp(s.nic,data[j].nic)==0)
	  {
	  	printf(" wrong NIC no Please reenter NIC no. ");
	  	gets(s.nic);
	  	j=0;
	  }
	 }
       printf("Enter username ");
       gets(s.username);
     for(j=0;j<i;)
     {
      if(strcmp(s.username,data[j].username)==0)
	  {
	  	printf("this username already exist please enter another username ");
	  	gets(s.username);
	  	j=0;
	  }
	  else
	  {
	  	j++;
	  }
	 }
     printf("Enter password ");
     gets(s.password);
     printf("Enter salary ");
     scanf("%f",&s.salary);
     while(1)
     {
     	fflush(stdin);
     printf("Enter date/month/year of joinig ");
     scanf("%d%d%d",&s.date,&s.month,&s.year);
    if(s.date>=1 && s.date<=31)
    {
    	if(s.month>=1 && s.month<=12)
    	{
    		break;
		}
	}
	    printf("Wrong input [D/M/Y] reenter date \n");
   	    continue;
     }
     for(j=0;s.password[j]!='\0';j++)
     {
     	s.password[j]=s.password[j]+2;
	 }
  	     fp=fopen("admin.txt","ab");
    	fwrite(&s,sizeof(struct pro),1,fp);
     	fclose(fp);}
void admin(int *a)                                      
{
	system("cls");
	FILE *fp;
	int i,j,check=0,count=0;
	struct pro s;
	fp=fopen("admin.txt","rb");
	while(fread(&s,sizeof(struct pro),1,fp))
	{
		count++;
	}
	struct pro *p;
	fp=fopen("admin.txt","rb");
	p=(struct pro*) calloc(count,sizeof(struct pro));
	fread(p,sizeof(struct pro),count,fp);
	fclose(fp);
	fflush(stdin);
	printf("\n\n\n\n\t\t\t\t\tEnter username ");
	gets(s.username);
	for(i=0;i<count;i++)
	{
		if(strcmp(s.username,p[i].username)==0)
		{
			printf("\n\n\t\t\t\t\tEnter password ");
			gets(s.password);
			for(j=0;p[i].password[j]!='\0';j++)
			{
				p[i].password[j]=p[i].password[j]-2;
			}
			if(strcmp(s.password,p[i].password)==0)
			{
				j=i;
			   check=1;
			   break;
			}
			else
			{
				j=i;
				check=2;
			}
		}
	}
	if(check==1)
	{
		while(1)
		{
			system("cls");
			printf("\n\n\n\t\t\t\tHello Mr %s \n\n\n",p[j].name);
			printf("1 Edit Menu card \n\n2 Display Menu card \n\n3 Customers detail \n\n4 Delete customer account \n\n5 Back\n\n6 Exit\n\n select ");
			scanf("%d",&i);
			if(i==1)
			{
				editmenu();
			}
			if(i==2)
			{
				display();
				getch();
			}
			if(i==4)
			{
				dltcustomer();
			}
			if(i==5)
			{
				break;
			}
			if(i==6)
			{
				*a=4;
				break;
			}
			if(i==3)
			{
				customerwallet();
			}
		}
	}
	if(check==2)
	{printf("press 1 for forget password ");
				scanf("%d",&i);
				if(i==1)
				{
		findme(p[j]);}
		free(p);
              	}
	
}
void display(void)                                       
{
   FILE *fp;
   int i=0;
   struct menu s;
   fp=fopen("menu.txt","rb");
   printf("Item No.\t\t\tName \t\t\tPrice/kg\n\n ");
   while(fread(&s,sizeof(struct menu),1,fp))
   {
   	printf("%d\t\t\t%s\t\t\t%f\n ",i+1,s.name,s.price);
   	i++;
   }	
}
void editmenu(void)                                  
{
	FILE *fp;
	struct menu *p,s;
	int a,count=0,i,j;
	display();
	printf("\n\n1 add new item \n\n2 delete any item \n\n3 create new menu card \n\n select ");
	scanf("%d",&a);
	if(a==1)
	{
		fflush(stdin);
		printf("Enter name of item ");
		gets(s.name);
		printf("Enter price in float");
		scanf("%f",&s.price);
		fp=fopen("menu.txt","ab");
		fwrite(&s,sizeof(struct menu),1,fp);
		fclose(fp);
	}
	if(a==2)
	{
		fp=fopen("menu.txt","rb");
		while(fread(&s,sizeof(struct menu),1,fp))
		{
			count++;
		}
		p=(struct menu*) calloc(count,sizeof(struct menu));
		fp=fopen("menu.txt","rb");
		fread(p,sizeof(struct menu),count,fp);
		fclose(fp);
		printf("Enter the number item number that you want delete ");
		scanf("%d",&i);
		for(j=i-1;j<count;j++)
		{
			p[j]=p[j+1];
		}
		fp=fopen("menu.txt","wb");
		fwrite(p,sizeof(struct menu),count-1,fp);
		fclose(fp);
		free(p);
	}
	if(a==3)
	{
		printf("\n\n your previous menu card will be delete press 1 for confirm ");
		scanf("%d",&i);
		if(i==1)
		{
			fflush(stdin);
			printf("Enter name of item ");
			gets(s.name);
			printf("Enter the price in float ");
			scanf("%f",&s.price);
			fp=fopen("menu.txt","wb");
		    fwrite(&s,sizeof(struct menu),1,fp);
		    fclose(fp);
	   }
	}
}
void adminread(struct pro*p,int i)
{
	FILE *fp;
	fp=fopen("admin.txt","rb");
	fread(p,sizeof(struct pro),i,fp);
	fclose(fp);
}
void admincount(int *i)
{
	struct pro s;
	FILE *fp;
	fp=fopen("admin.txt","rb");
	while(fread(&s,sizeof(struct pro),1,fp))
	{
	      *i=  *i+1;
	}
}
void findme(struct pro id)
{
	char a[100];
	printf("Enter your NIC ");
	fflush(stdin);
	gets(a);
	if(strcmp(a,id.nic)==0)
	{
		printf("\nUsername %s \nPassword  %s",id.username,id.password);
		getch();
	}
}                               
void customer(void)                  ///  not start
{
   float sum=0,temp;
	FILE *fp;
	float pay;
	struct pro o,*p;
	int a,k,check,i=0,j,d=0,b;
	while(1)
	{
	printf("\t\t1 order (without login)\n\n \t\t2 Login (membership) \n\n\t\t3 Back \n\n ");
	scanf("%d",&a);
	if(a==1)
	{
		while(1)
		{
		printf("\n\n\t1 order \n\n\t2 Menu card \n\n\t3 registration for membership \n\n\t4 Bill\n\n\t5 back\n\n ");
		scanf("%d",&k);
		if(k==1)
		{
			order(&sum,1);
		}
		if(k==2)
		{
			display();
		}
		if(k==3)
		{
			customerreg();
		}
		if(k==4)
		{
			printf(" Total Bill %f press 1 for pay ",sum);
			scanf("%d",&check);
			if(check==1)
			{
				printf("Enter amount ");
				scanf("%f",&pay);
				sum=sum-pay;
				if(sum>0)
				{
					printf("remaining Bill %.2f Pkr ",sum);
					getch();
				}
				if(sum<0)
				{
					printf("Please take your %f Pkr ",-sum);
					getch();
					sum=0;
				}
				if(sum==0)
				{
					printf("Thanks for pay ");
				}
			}
		}
		if(k==5)
		{
			break;
		}
	} } 
	if(a==2)
	{
		sum=0;
		printf("Enter username ");
		fflush(stdin);
		gets(o.username);
		customercount(&i);
		p=(struct pro *) calloc(i,sizeof(struct pro));
		customerread(p,i);
		for(j=0;j<i;j++)
         {
         	if(strcmp(p[j].username,o.username)==0)
         	{
         		printf("Enter password ");
         		gets(o.password);
         		for(d=0;p[j].password[d]!='\0';d++)
         		{
         			p[j].password[d]=p[j].password[d]-2;
				 }
				 if(strcmp(p[j].password,o.password)==0)
				 {
				 	while(1)
				 	{
				 		system("cls");
				 		printf("\n\n\t\t\tWelcome Mr %s \n\n\n",p[j].name);
				 		printf(" * Congratulation now you can get FLAT 30 percent Disscount to use your wallet ");
				 		printf("\n\n1 order \n\n2 Bill \n\n3 menu card \n\n4 Wallet balance\n\n5 add in wallet \n\n6 back \n\n select ");
				 		scanf("%d",&b);
				 		if(b==1)
				 		{
				 			order(&sum,1);
						}
						if(b==2)
						{
							printf(" current bill %f ",sum);
							printf("press 1 for pay cash/debit 2 for use wallet and get 30 percent disscount ");
							scanf("%d",&check);
							if(check==1)
							{
								printf("\n\n1 Debit card\n\n2 Cash \n\n select ");
								scanf("%d",&d);
								if(d==1)
								{
									printf("Enter Debit card Number ");
									scanf("%d",&k);
									printf("Enter amount ");
									scanf("%f",&pay);
									sum=sum-pay;
									if(sum>0)
									{
										printf("Remaining bill %.2f",sum);
										getch();
									}
									if(sum<0)
									{
										printf("Please take you %.2f pkr from counter ",sum);
										getch();
										sum=0;
									}
									if(sum==0)
									{
										printf("Thanks for pay ");
									}
								}
								
								if(d==2)
								{
								  printf("Enter amount ");
								  scanf("%f",&pay);
								  sum=sum-pay;
								  if(sum>0)
									{
										printf("Remaining bill %.2f",sum);
										getch();
									}
									if(sum<0)
									{
										printf("Please take you %.2f pkr from counter ",sum);
										getch();
										sum=0;
									}
									if(sum==0)
									{
										printf("Thanks for pay ");
									}
							    }
								
								}
							if(check==2)
							{
								system("cls");
								printf("\n\nbefore disscount bill %.2f \n",sum);
								sum=sum-(sum*0.3);
								p[j].wallet=p[j].wallet-sum;
								for(d=0;p[j].password[d]!='\0';d++)
								{
									p[j].password[d]=p[j].password[d]+2;
								}
								fp=fopen("customer.dat","wb");
								fwrite(p,sizeof(struct pro),i,fp);
								fclose(fp);
								printf("After disscount %.2f \n",sum);
								
								printf("\nyour current wallet balance is %f ",p[j].wallet);
								printf("\n\n\t\t\t\t*****************Thanks For shopping **************************");
								exit(1);
							}
						}
						if(b==3)
						{
							display();
						}
						if(b==4)
						{
							printf("current wallet  balance is  %.2f ",p[j].wallet);
							getch();
							
						}
						if(b==6)
						{
							break;
						}
						if(b==5)
						{
							printf("current balance %.2f ",p[j].wallet);
							printf("\n\n add amount ");
							scanf("%f",&temp);
							p[j].wallet=p[j].wallet+temp;
							for(d=0;p[j].password[d]!='\0';d++)
								{
									p[j].password[d]=p[j].password[d]+2;
								}
								fp=fopen("customer.dat","wb");
								fwrite(p,sizeof(struct pro),i,fp);
								if(fp!=NULL)
								{
									printf("\n Successfully added your new balance is %.2f",p[j].wallet);
								}
								fclose(fp);
								exit(1);
						}
					 }
				 	break;
				 }
				 else
				 {
				 	printf("press 1 for forget password ");
				 	scanf("%d",&d);
				 	if(d==1)
				 	{
				 		findme(p[j]);
					 }
				 }
			 }
		 }
		 
	}
	if(a==3)
	{
		break;
    }}}
void customerreg(void)
{
	system("cls");
	FILE *fp;
	int i=0,j=0;
	struct pro p,*g;
	fflush(stdin);
    printf("\n\n\n\n\t\tEnter name ");
	gets(p.name);
	printf("\n\n\t\tEnter your NIC no.");
	gets(p.nic);
	printf("\n\n\t\tEnter usename ");
	 gets(p.username);
	customercount(&i);
	if(i>0)
	{
		g= (struct pro*) calloc(i,sizeof(struct pro));
		customerread(g,i);
		for(j=0;j<i;)
		{
	         if(strcmp(p.username,g[j].username)==0)
	         {
	         	printf("\n\n\t\t\tthis username already exists please renter username \n");
	         	 gets(p.username);
	         	j=0;
			 }
			 else
			 {
			 	j++;
			 }
		}
		for(j=0;j<i;)
		{
			if(strcmp(p.nic,g[j].nic)==0)
			{
				printf("\n\t\t\tincorrect NIC no please enter your correct NIC no ");
				gets(p.nic);
				j=0;
			}
			else
			{
				j++;
			}
		}
		free(g);
	}
	printf("\n\n\t\tEnter password ");
	gets(p.password);
	j=0;
	while(p.password[j]!='\0')
	{
		p.password[j]=p.password[j]+2;
		j++;
	}
	printf("\n\n\t\tEnter your Email address ......@gmail.com ");
	gets(p.email);
	p.wallet=0.0;
	fp=fopen("customer.dat","ab");
	fwrite(&p,sizeof(struct pro),1,fp);
	fclose(fp);
		
}
void customercount(int *i)
{
	FILE *fp;
	fp=fopen("customer.dat","rb");
	struct pro p;
	while(fread(&p,sizeof(struct pro),1,fp))
	{
		*i=*i+1;
	}
}
void customerread(struct pro *p,int i)
{
	int j=0;
	FILE *fp;
	fp=fopen("customer.dat","rb");
	fread(p,sizeof(struct pro),i,fp);
	fclose(fp);
}
void customerwallet(void)                    //     check both admins and customer are using 
{ 
	system("cls");
	FILE *fp;
	struct pro c;
	fp=fopen("customer.dat","rb");
	printf("Name of customer\t\tNIC NO.\t\t\tWallet\t\t\tEmail address \n\n");
	while(fread(&c,sizeof(struct pro),1,fp))
	printf("%s\t\t\t%s\t\t\t%.2f\t\t\t%s@gmail.com\n",c.name,c.nic,c.wallet,c.email);
	getch();
	system("cls");
}
void order(float *sum,int per)
{     int count=0,ch;
       struct menu *p;
	  struct menu temp; 
	  float quant;
      FILE *fp;
            if(per==1)
             { system("cls");
               fp=fopen("menu.txt","rb");
               while(fread(&temp,sizeof(struct menu),1,fp))
               {
               	count++;
			   }
			   p=(struct menu*) calloc(count,sizeof(struct menu));
			    fp=fopen("menu.txt","rb");
			    fread(p,sizeof(struct menu),count,fp);
			    fclose(fp);
			    display();
			    printf("\nchoose item no. ");
			    scanf("%d",&ch);
			    if(ch>0 && ch<=count)
			    {
			    	printf("Enter quantity ");
			    	scanf("%f",&quant);
			    	*sum=*sum+(p[ch-1].price*quant);
				}
				else
				{
					printf("\n\n\t\t\tinvalid input\n");
				}
				free(p);
				printf("enter 1 for continue your order ");
				scanf("%d",&per);
				order(sum,per);
	         }
}
void dltcustomer(void)
{
	FILE *fp;
	char nc[100];
	struct pro *p;
	int per=0,a=0,j,note;
	customercount(&a);
	p=(struct pro*)calloc(a,sizeof(struct pro));
	customerread(p,a);
	fflush(stdin);
	printf("Enter NIC Number of customer that you want remove  ");
	gets(nc);
	for(j=0;j<a;j++)
	{
		if(strcmp(p[j].nic,nc)==0)
		{
			note=j;
			per=1;
			break;
		}
	}
	if(per==1)
	{
         	for(j=note;j<a;j++)
			{
				p[j]=p[j+1];
			}
			fp=fopen("customer.dat","wb");
	        fwrite(p,sizeof(struct pro),a-1,fp);
           	fclose(fp);
	      free(p);
}}
